package com.samanthabarco.volleyavance;

import android.widget.Toast;

import java.io.Serializable;

public class Vigilante implements Serializable {
    int vigilante_id, permiso;
    String nombre, apellidos, correo, contrasenia;

    //Métodos GET
    public String getNombre()
    {
        return nombre;
    }

    public String getApellidos()
    {
        return apellidos;
    }

    public String getCorreo()
    {
        return correo;
    }

    public String getContrasenia()
    {
        return contrasenia;
    }

    public int getID()
    {
        return vigilante_id;
    }

    public int getPermiso()
    {
        return permiso;
    }


    public String getTodo()
    {
        return "Tus datos son los siguientes:\n"+
                "ID: "+ Integer.toString(this.getID())+"\n"+
                "Nombre: "+ this.getNombre()+"\n"+
                "Apellidos: "+ this.getApellidos()+"\n"+
                "Correo: "+ this.getCorreo()+"\n"+
                "Contrasenia: "+ this.getContrasenia()+"\n"+
                "Permisos: "+ Integer.toString(this.getPermiso())+"\n";
    }

    public String datosAdministrar()
    {
        if(this.getPermiso()==1)
            return  "El usuario cuenta con permisos de administrador.\n"+
                    "ID: "+ Integer.toString(this.getID())+"\n"+
                    "Nombre: "+ this.getNombre()+"\n"+
                    "Apellidos: "+ this.getApellidos()+"\n"+
                    "Correo: "+ this.getCorreo()+"\n";
        else
            return  "El usuario cuenta con permisos de vigilante.\n"+
                    "ID: "+ Integer.toString(this.getID())+"\n"+
                    "Nombre: "+ this.getNombre()+"\n"+
                    "Apellidos: "+ this.getApellidos()+"\n"+
                    "Correo: "+ this.getCorreo()+"\n";

    }

    //Métodos SET
    public void setNombre(String n)
    {
        this.nombre = n;
    }

    public void setApellidos(String a)
    {
        this.apellidos = a;
    }

    public void setCorreo(String c)
    {
        this.correo = c;
    }

    public void setContrasenia(String c)
    {
        this.contrasenia = c;
    }

    public void setID(String i)
    {
        this.vigilante_id = Integer.parseInt(i);
    }

    public void setPermiso(String p)
    {
        this.permiso = Integer.parseInt(p);
    }

    public void setTodo(String nom, String ap, String cor, String con, String i, String p)
    {
        this.nombre = nom;
        this.apellidos = ap;
        this.correo = cor;
        this.contrasenia = con;
        this.vigilante_id = Integer.parseInt(i);
        this.permiso = Integer.parseInt(p);
        return;
    }

    //Otros

    public boolean verificarContrasenia(String c)
    {
        if(c.equals(this.getContrasenia()))
            return true;
        return false;
    }
}
