package com.samanthabarco.volleyavance;

//Funcion para pasar de un objeto JSON a un vigilante

import org.json.JSONException;
import org.json.JSONObject;

public class JSONaVigilante {

    public static Vigilante parseaObjeto(JSONObject obj)
    {
        try {
            Vigilante vigilante = new Vigilante();

            vigilante.setNombre(obj.getString("nombre"));
            vigilante.setApellidos(obj.getString("apellidos"));
            vigilante.setCorreo(obj.getString("correo"));
            vigilante.setContrasenia(obj.getString("contrasenia"));
            vigilante.setID(obj.getString("vigilante_id"));
            vigilante.setPermiso(obj.getString("permiso"));

            return vigilante;

        }catch (JSONException el){
            el.printStackTrace();
            return null;
        }
    }

}
