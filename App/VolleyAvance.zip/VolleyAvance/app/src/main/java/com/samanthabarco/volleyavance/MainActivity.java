package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    //URL de servicio para recuperar datos del vigilante
    private String URL_VIGILANTE_INFO = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/test/recuperarVigilante.php/?correo=";
    private String URL_VIGILANTE_INFO2 = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/recuperarVigilante.php/?correo=";

    //Componenetes necesarios
    ProgressDialog barradeProgreso;
    private EditText correoET;
    private EditText contraseniaET;
    LinearLayout layout;

    //Variables necesarias
    private static final String TAG = "LogIn";
    private String  correoString;
    private String contraseniaString;
    private String editedURL;
    Vigilante vigilante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Referencia a elementos del layout
        correoET = (EditText) findViewById(R.id.editText);
        contraseniaET = (EditText) findViewById(R.id.editText2);

        cambiarLayout();
    }

    void cambiarLayout() //Función para cambiar el layout
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        barradeProgreso = new ProgressDialog(this);
    }

    public void ingresar(View v) //Función para ingresar a la aplicación
    {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);

        correoString = correoET.getText().toString();
        contraseniaString = contraseniaET.getText().toString();
        editedURL = URL_VIGILANTE_INFO.concat(correoString);

        imm.hideSoftInputFromWindow(contraseniaET.getWindowToken(), 0);

        volleyJsonArrayRequest(URL_VIGILANTE_INFO2.concat(correoString));
    }

    private void DespliegaToast(String msg) //Función para desplegar un Toast
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    public void volleyJsonArrayRequest(String url)  //Función que recupera el vigilante de la base de datos
    {
        String  REQUEST_TAG = "com.samanthabarco.volleyavance.VigilanteRequest";
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();

        JsonArrayRequest peticion = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override public void onResponse(JSONArray response) {
                barradeProgreso.hide();
                try {
                    JSONObject autenticacion = (JSONObject) response.get(0);
                    String codigo_autenticacion = autenticacion.getString("Codigo");
                    String mensaje = autenticacion.getString("Mensaje");
                    if(codigo_autenticacion.equals("1")) //Si el mensaje no muestra error, entonces lee la información del vigilante
                    {
                        JSONObject vigilanteObjeto = (JSONObject) response.get(1);
                        vigilante = JSONaVigilante.parseaObjeto(vigilanteObjeto);
                        if (vigilante.getContrasenia().equals(contraseniaString)) //Si la contraseña es correcta lo envía a la pantalla correspondiente
                        {
                            if(vigilante.getPermiso() == 1) {
                                Intent actividad = new Intent(MainActivity.this, adminMenu.class);
                                startActivity(actividad);
                            }
                            else if(vigilante.getPermiso() == 0)
                            {
                                Intent actividad = new Intent(MainActivity.this, vigilanteMenu.class);
                                startActivity(actividad);
                            }
                        }
                        else //De lo contrario despliega un mensaje de error
                        {
                            DespliegaToast("Contraseña incorrecta.");
                        }
                    }
                    else //Si no recibe un vigilante despliega el error devuelto por el servicio
                    {
                        DespliegaToast(mensaje+".");
                    }
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this, "Problema en: " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override public void onErrorResponse(VolleyError error) {
                barradeProgreso.hide();
                Toast.makeText(MainActivity.this, "Error en: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        //Añade la solicitud a la cola
        Singleton.getInstance(getApplicationContext()).addToRequestQueue(peticion,REQUEST_TAG);
        return;
    }
}
