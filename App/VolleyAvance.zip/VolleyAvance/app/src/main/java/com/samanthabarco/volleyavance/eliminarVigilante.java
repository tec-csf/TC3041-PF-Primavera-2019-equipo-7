package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class eliminarVigilante extends AppCompatActivity {

    Vigilante administrador;
    LinearLayout layout;

    private EditText correoET;

    private String correoS;

    private static final String TAG = "Eliminar";
    private String URL_VIGILANTE_CORREO;

    ProgressDialog barradeProgreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar_vigilante);

        cambiarLayout();
        obtenerElementos();
    }

    void cambiarLayout() {
        //Elementos a cambiar
        layout = (LinearLayout) findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        barradeProgreso = new ProgressDialog(this);
    }

    void obtenerElementos() {
        correoET = (EditText) findViewById(R.id.editTextCorreo);
    }

    void obtenerStrings() {
        correoS = correoET.getText().toString();
    }

    int verificarStrings() {
        if (correoS.equals("")) {
            correoET.setError("Debes añadir un correo");
            return 1;
        } else if (correoS.contains(" ") || !correoS.contains("@") || !correoS.contains(".")) {
            correoET.setError("Correo inválido.");
            return 1;
        }
        return 0;
    }

    void setURL() {
        URL_VIGILANTE_CORREO = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/eliminarVigilante.php/?correo=" +
                correoS;
    }

    private void DespliegaToast(String msg)
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    public void eliminarVigilante(View v)
    {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(correoET.getWindowToken(), 0);
        obtenerStrings();
        if(verificarStrings()==1) return;
        setURL();
        volleyEliminarVigilante(URL_VIGILANTE_CORREO);
    }

    public void volleyEliminarVigilante(String url)
    {
        String  REQUEST_TAG = "com.samanthabarco.volleyavance.eliminarVigilante";
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();

        JsonArrayRequest peticion = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override public void onResponse(JSONArray response) {
                barradeProgreso.hide();
                try {
                    JSONObject autenticacion = (JSONObject) response.get(0);
                    String codigo_autenticacion = autenticacion.getString("Codigo");
                    String mensaje = autenticacion.getString("Mensaje");
                    DespliegaToast(mensaje+".");


                } catch (JSONException e) {
                    Toast.makeText(eliminarVigilante.this, "Problema en: " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override public void onErrorResponse(VolleyError error) {
                barradeProgreso.hide();
                Toast.makeText(eliminarVigilante.this, "Error en: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        Singleton.getInstance(getApplicationContext()).addToRequestQueue(peticion,REQUEST_TAG);
        return;
    }
}
