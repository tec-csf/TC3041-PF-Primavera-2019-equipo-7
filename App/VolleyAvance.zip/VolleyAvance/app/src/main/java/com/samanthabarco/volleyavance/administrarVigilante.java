
package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class administrarVigilante extends AppCompatActivity {

    Vigilante administrador;
    LinearLayout layout;

    //URL de servicio para recuperar datos del vigilante
    private String URL_VIGILANTE_INFO = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/recuperarVigilante.php/?correo=";
    private String URL_EDITAR_INFO = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/actualizarVigilante2.php/?";

    //Componenetes necesarios
    private static final String TAG = "Administrar";
    ProgressDialog barradeProgreso;
    private EditText correoETE;
    private EditText correoET;
    private EditText nombreET;
    private EditText apellidosET;
    private RadioButton vigilanteRB;
    private RadioButton administradorRB;
    private RadioGroup radioButtons;
    private TextView datos;
    private String  correoS;
    private String editedURL;

    private String nombreS;
    private String apellidosS;
    private String correoNuevoS;
    private String permisoS;

    private int respuesta;

    Vigilante vigilanteEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrar_vigilante);

        cambiarLayout();
        obtenerElementos();
        desactivarElementos();
    }

    void cambiarLayout()
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        barradeProgreso = new ProgressDialog(this);
    }

    void obtenerElementos()
    {
        correoETE = (EditText) findViewById(R.id.editTextCorreoEntrada);
        datos = (TextView) findViewById(R.id.textViewDatos);
        correoET = (EditText) findViewById(R.id.editTextCorreo);
        nombreET = (EditText) findViewById(R.id.editTextNombre);
        apellidosET = (EditText) findViewById(R.id.editTextApellidos);
        vigilanteRB = (RadioButton) findViewById(R.id.radioButtonVigilante);
        administradorRB = (RadioButton) findViewById(R.id.radioButtonAdministrador);
        radioButtons = (RadioGroup) findViewById(R.id.radioGroup);
    }

    void vaciarElementos()
    {
        correoETE.setText("");
        datos.setText("Los datos del vigilante son los siguientes:");
        correoET.setText("");
        nombreET.setText("");
        apellidosET.setText("");
        radioButtons.clearCheck();
    }

    void desactivarElementos()
    {
        correoET.setEnabled(false);
        nombreET.setEnabled(false);
        apellidosET.setEnabled(false);
        vigilanteRB.setEnabled(false);
        administradorRB.setEnabled(false);
    }

    void activarElementos()
    {
        correoET.setEnabled(true);
        nombreET.setEnabled(true);
        apellidosET.setEnabled(true);
        vigilanteRB.setEnabled(true);
        administradorRB.setEnabled(true);
    }

    void obtenerStringCorreo() {
        correoS = correoETE.getText().toString();
    }

    int verificarStringCorreo() {
        if (correoS.equals("")) {
            correoETE.setError("Debes añadir un correo");
            return 1;
        } else if (correoS.contains(" ") || !correoS.contains("@") || !correoS.contains(".")) {
            correoETE.setError("Correo inválido.");
            return 1;
        }
        return 0;
    }

    void setURLInfo() {
        editedURL = URL_VIGILANTE_INFO + correoS;
    }

    private void DespliegaToast(String msg)
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    public void recuperarVigilante(View v)
    {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(correoETE.getWindowToken(), 0);
        obtenerStringCorreo();
        if(verificarStringCorreo()==1) return;
        setURLInfo();
        volleyJsonArrayRequest(editedURL);
    }

    void setElementos()
    {
        datos.setText( "Datos del vigilante con ID "+ Integer.toString(vigilanteEditar.getID()));
        nombreET.setText(vigilanteEditar.getNombre());
        apellidosET.setText(vigilanteEditar.getApellidos());
        correoET.setText(vigilanteEditar.getCorreo());
        radioButtons.clearCheck();
        if(vigilanteEditar.getPermiso()==1) administradorRB.setChecked(true);
        else if(vigilanteEditar.getPermiso()==0) vigilanteRB.setChecked(true);
        permisoS = Integer.toString(vigilanteEditar.getPermiso());
    }

    public void volleyJsonArrayRequest(String url) {
        String  REQUEST_TAG = "com.samanthabarco.volleyavance.VigilanteRequest";
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();

        JsonArrayRequest peticion = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override public void onResponse(JSONArray response) {
                barradeProgreso.hide();
                try {
                    JSONObject autenticacion = (JSONObject) response.get(0);
                    String codigo_autenticacion = autenticacion.getString("Codigo");
                    String mensaje = autenticacion.getString("Mensaje");
                    if(codigo_autenticacion.equals("1"))
                    {
                        JSONObject vigilanteObjeto = (JSONObject) response.get(1);
                        vigilanteEditar = JSONaVigilante.parseaObjeto(vigilanteObjeto);
                        setElementos();
                        activarElementos();
                    }
                    else
                    {
                        DespliegaToast(mensaje+".");
                    }


                } catch (JSONException e) {
                    Toast.makeText(administrarVigilante.this, "Problema en: " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override public void onErrorResponse(VolleyError error) {
                barradeProgreso.hide();
                Toast.makeText(administrarVigilante.this, "Error en: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        Singleton.getInstance(getApplicationContext()).addToRequestQueue(peticion,REQUEST_TAG);
        return;
    }


    public void actualizarVigilante(View v)
    {
        obtenerStrings();
        if(verificarStrings()==1) return;
        setURLEditar();
        //DespliegaToast(editedURL);
        volleyIntegerRequest(editedURL);
    }

    void setURLEditar()
    {
        eliminarEspacios();
        //nombre=Sam&correoOrig=sbm222&correoNuevo=sbm22&apellidos=Barco%20Mejia&permiso=1
        editedURL = URL_EDITAR_INFO +
                "nombre="+nombreS+
                "&correoOrig="+correoS+
                "&correoNuevo="+correoNuevoS+
                "&apellidos="+apellidosS+
                "&permiso="+permisoS;
    }

    void obtenerStrings()
    {
        nombreS = nombreET.getText().toString();
        apellidosS = apellidosET.getText().toString();
        correoNuevoS = correoET.getText().toString();
    }

    public void cargoAdministrador(View v)
    {
        permisoS = "1";
    }

    public void cargoVigilante(View v)
    {
        permisoS = "0";
    }

    void eliminarEspacios()
    {
        nombreS = nombreS.replace(" ","%20");
        apellidosS = apellidosS.replace(" ","%20");
    }

    int verificarStrings()
    {
        int error = 0;
        if(nombreS.equals("")) {
            nombreET.setError("Debes añadir un nombre.");
            error++;
        }
        if(apellidosS.equals("")) {
            apellidosET.setError("Debes añadir apellidos.");
            error++;
        }
        if(correoS.equals("")) {
            correoET.setError("Debes añadir un correo");
            error++;
        }
        if (correoS.contains(" ") || !correoS.contains("@") || !correoS.contains("."))
        {
            correoET.setError("Correo inválido.");
            error++;
        }
        if(permisoS == null) {
            DespliegaToast("Selecciona un cargo.");
            error++;
        }
        if(error>0) return 1;
        return 0;
    }

    public void volleyIntegerRequest(String url){
        // REQUEST_TAG es utilizado para cancelar un request
        String  REQUEST_TAG = "com.samanthabarco.volleyavance.eliminarVigilante";
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();

        JsonArrayRequest peticion = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override public void onResponse(JSONArray response) {
                barradeProgreso.hide();
                try {
                    JSONObject autenticacion = (JSONObject) response.get(0);
                    String codigo_autenticacion = autenticacion.getString("Codigo");
                    String mensaje = autenticacion.getString("Mensaje");
                    DespliegaToast(mensaje+".");
                    vaciarElementos();

                } catch (JSONException e) {
                    Toast.makeText(administrarVigilante.this, "Problema en: " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override public void onErrorResponse(VolleyError error) {
                barradeProgreso.hide();
                Toast.makeText(administrarVigilante.this, "Error en: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        Singleton.getInstance(getApplicationContext()).addToRequestQueue(peticion,REQUEST_TAG);
        return;
    }

}
