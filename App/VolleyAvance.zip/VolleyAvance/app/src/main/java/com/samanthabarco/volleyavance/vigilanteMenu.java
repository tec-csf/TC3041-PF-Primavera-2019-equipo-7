package com.samanthabarco.volleyavance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;

public class vigilanteMenu extends AppCompatActivity {

    //Elementos del layout a editar
    LinearLayout layout;
    TextView bienvenida;

    //Vigilante para shared preferences
    Vigilante vigilante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vigilante_menu);

        obtenerVigilante();
        cambiarLayout();
    }

    void obtenerVigilante() //Función para recuperar vigilante de Shared preferences
    {
        //Variables necesarias
        Gson gson = new Gson();
        vigilante = new Vigilante();
        String json;
        SharedPreferences sp;

        //Recupera shared preferences y almacena el vigilante
        sp = getSharedPreferences("crm", Context.MODE_PRIVATE);
        json = sp.getString("vigilante","");
        vigilante = gson.fromJson(json, Vigilante.class);

        return;
    }

    void cambiarLayout() //Función para cambiar el layout
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);
        bienvenida = (TextView) findViewById(R.id.nombre);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        //Cambiar nombre
        cambiarBienvenida();
    }

    void cambiarBienvenida()  //Función para cambiar el mensaje de bienvenida
    {
        if(vigilante != null)
            bienvenida.setText(vigilante.getNombre()+ " " + vigilante.getApellidos());
    }


    public void QRBtn(View v) //Función para iniciar lectura de QR
    {
        Intent actividad = new Intent(vigilanteMenu.this, leerQR.class);
        startActivity(actividad);
    }

    public void envioManualBtn(View v) //Función para iniciar el registro de un envío manualmente
    {
        Intent actividad = new Intent(vigilanteMenu.this, agregarEnvio.class);
        startActivity(actividad);
    }

    public void salirBtn(View v)
    {
        finish();
    } //Función para salir de la cuenta
}
