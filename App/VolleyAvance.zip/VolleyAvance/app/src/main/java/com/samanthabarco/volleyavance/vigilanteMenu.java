package com.samanthabarco.volleyavance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;

public class vigilanteMenu extends AppCompatActivity {

    LinearLayout layout;
    TextView bienvenida;
    Vigilante vigilante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vigilante_menu);

        obtenerVigilante();
        cambiarLayout();
    }

    void obtenerVigilante()
    {
        vigilante = new Vigilante();

        //Crear sharedPreferences
        SharedPreferences sp = getSharedPreferences("crm", Context.MODE_PRIVATE);

        Gson gson = new Gson();
        String json = sp.getString("vigilante","");
        vigilante = gson.fromJson(json, Vigilante.class);

        return;
    }

    void cambiarLayout()
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);
        bienvenida = (TextView) findViewById(R.id.nombre);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        //Cambiar nombre
        cambiarBienvenida();
    }

    void cambiarBienvenida()
    {
        if(vigilante != null)
            bienvenida.setText(vigilante.getNombre()+ " " + vigilante.getApellidos());
    }


    public void QRBtn(View v)
    {
        Intent actividad = new Intent(vigilanteMenu.this, leerQR.class);
        startActivity(actividad);
    }

    public void envioManualBtn(View v)
    {
        Intent actividad = new Intent(vigilanteMenu.this, agregarEnvio.class);
        startActivity(actividad);
    }

    public void salirBtn(View v)
    {
        finish();
    }
}
