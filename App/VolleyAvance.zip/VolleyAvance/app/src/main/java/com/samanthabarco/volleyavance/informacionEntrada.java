package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class informacionEntrada extends AppCompatActivity {

    TextView placasVehiculo;
    TextView informacionVehiculo;
    TextView placasContenedor;
    TextView informacionContenedor;
    TextView origen;
    TextView conductor;
    TextView material;
    TextView peso;

    LinearLayout layout;

    FirebaseFirestore db;

    private static final String TAG = "Recuperar";

    private String coleccionEnvios = "envios/";
    private String coleccionContenedores = "contenedores/";
    private String coleccionConductores = "conductores/";
    private String coleccionCamiones = "camiones/";
    private String coleccionProveedores = "proveedores/";

    private String documentoEnvio;

    private String nombreConductor;
    private String datosCamion;
    private String datosContenedor;
    private String nombreProveedor;
    private String direccionProveedor;

    private Envio envioRecuperado;

    ProgressDialog barradeProgreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion_entrada);

        db = FirebaseFirestore.getInstance();

        barradeProgreso = new ProgressDialog(this);

        envioRecuperado = new Envio();

        cambiarLayout();

        obtenerElementos();
        obtenerExtras();

        recuperarEnvio();

    }

    void cambiarLayout()
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);
    }

    void obtenerElementos()
    {
        placasVehiculo = (TextView) findViewById(R.id.placasVehiculoText);
        informacionVehiculo = (TextView) findViewById(R.id.vehiculoText);
        placasContenedor  = (TextView) findViewById(R.id.placasContenedorText);
        informacionContenedor = (TextView) findViewById(R.id.contenedorText);
        origen = (TextView) findViewById(R.id.origenText);
        conductor = (TextView) findViewById(R.id.conductorText);
        material = (TextView) findViewById(R.id.materialText);
        peso = (TextView) findViewById(R.id.pesoText);
    }

    void obtenerExtras()
    {
        Intent intent = getIntent();

        documentoEnvio = intent.getStringExtra("id");
    }

    void recuperarEnvio()
    {
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();
        db.document(coleccionEnvios+documentoEnvio)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            envioRecuperado = documentSnapshot.toObject(Envio.class);
                            recuperarConductor();
                            recuperarCamion();
                            recuperarContenedor();
                            recuperarProveedor();
                        }
                        else
                        {
                            DespliegaToast("Documento envío no existe.");
                            finish();
                        }
                    }
                });
    }

    void recuperarConductor()
    {
        db.document(coleccionConductores+envioRecuperado.getIdConductor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            nombreConductor = documentSnapshot.getString("nombre");
                            nombreConductor = nombreConductor + " " + documentSnapshot.getString("apellidos");
                        }
                        else
                        {
                            DespliegaToast("Documento conductor no existe.");
                        }
                    }
                });
    }

    void recuperarCamion()
    {
        db.document(coleccionCamiones+envioRecuperado.getPlacasCamion())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            datosCamion = documentSnapshot.getString("marca");
                            datosCamion = datosCamion +" "+ documentSnapshot.getString("modelo");
                            datosCamion = datosCamion + " - " + documentSnapshot.getString("color");
                        }
                        else
                        {
                            DespliegaToast("Documento camión no existe.");
                        }
                    }
                });
    }

    void recuperarContenedor()
    {
        db.document(coleccionContenedores+envioRecuperado.getPlacasContenedor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            datosContenedor = documentSnapshot.getString("tipo");
                        }
                        else
                        {
                            DespliegaToast("Documento contenedor no existe.");
                        }
                    }
                });
    }

    void recuperarProveedor()
    {
        db.document(coleccionProveedores+envioRecuperado.getIdProveedor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            nombreProveedor = documentSnapshot.getString("nombre");
                            recuperarDireccion(coleccionProveedores+envioRecuperado.getIdProveedor());
                        }
                        else
                        {
                            DespliegaToast("Documento proveedor no existe.");
                        }
                    }
                });
    }

    void recuperarDireccion(String url)
    {
        db.document(url+"/direcciones/"+envioRecuperado.getIdDireccion())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            direccionProveedor = "\tColonia: "+documentSnapshot.getString("colonia");
                            direccionProveedor = direccionProveedor +"\n\tCalle:"+ documentSnapshot.getString("calle");
                            direccionProveedor = direccionProveedor +" \n\tNo. "+documentSnapshot.getString("numero");
                            direccionProveedor = direccionProveedor + "\n\tC.P: " + documentSnapshot.getString("codigoPostal");
                            despliegaInformacion();
                        }
                        else
                        {
                            DespliegaToast("Documento dirección no existe.");
                        }
                    }
                });
    }


    private void DespliegaToast(String msg)
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    private void despliegaInformacion()
    {
        placasVehiculo.setText("Camión: "+envioRecuperado.getPlacasCamion());
        informacionVehiculo.setText(datosCamion);

        placasContenedor.setText("Contenedor: "+envioRecuperado.getPlacasContenedor());
        informacionContenedor.setText(datosContenedor);

        origen.setText(nombreProveedor+"\n"+direccionProveedor);

        conductor.setText("Conductor: "+nombreConductor);

        material.setText("Material: " + envioRecuperado.getMaterial());
        peso.setText("Peso: " + envioRecuperado.getPeso());

        barradeProgreso.hide();
    }

    public void aceptarBtn(View v)
    {
        //get documento envio seet aceptado = 1
        Map<String,Object> datos = new HashMap<>();
        datos.put("aceptado", 1);

        db.collection(coleccionEnvios).document(documentoEnvio).set(datos, SetOptions.merge());
        DespliegaToast("Envío aceptado, el vehículo puede pasar.");

        finish();
    }

    public void negarBtn(View v)
    {
        Map<String,Object> datos = new HashMap<>();
        datos.put("aceptado", 0);

        db.collection(coleccionEnvios).document(documentoEnvio).set(datos, SetOptions.merge());
        DespliegaToast("Envío denegado correctamente.");

        finish();
    }
}
