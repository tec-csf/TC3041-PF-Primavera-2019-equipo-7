package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class informacionEntrada extends AppCompatActivity {

    //Elementos necesarios
    TextView placasVehiculo;
    TextView informacionVehiculo;
    TextView placasContenedor;
    TextView informacionContenedor;
    TextView origen;
    TextView conductor;
    TextView material;
    TextView peso;
    LinearLayout layout;
    ProgressDialog barradeProgreso;

    //Administrador de Firebase
    FirebaseFirestore db;

    //Variables necesarias para Firebase
    private static final String TAG = "Recuperar";
    private String coleccionEnvios = "envios/";
    private String coleccionContenedores = "contenedores/";
    private String coleccionConductores = "conductores/";
    private String coleccionCamiones = "camiones/";
    private String coleccionProveedores = "proveedores/";

    //Variables necesarias
    private String documentoEnvio;
    private String nombreConductor;
    private String datosCamion;
    private String datosContenedor;
    private String nombreProveedor;
    private String direccionProveedor;

    //Objeto envío
    private Envio envioRecuperado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion_entrada);

        db = FirebaseFirestore.getInstance();

        envioRecuperado = new Envio();

        cambiarLayout();

        obtenerElementos();
        obtenerExtras();

        recuperarEnvio();

    }

    void cambiarLayout() //Función para cambiar el layout
    {
        barradeProgreso = new ProgressDialog(this);

        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);
    }

    void obtenerElementos() //Función que obtiene los elementos del layout
    {
        placasVehiculo = (TextView) findViewById(R.id.placasVehiculoText);
        informacionVehiculo = (TextView) findViewById(R.id.vehiculoText);
        placasContenedor  = (TextView) findViewById(R.id.placasContenedorText);
        informacionContenedor = (TextView) findViewById(R.id.contenedorText);
        origen = (TextView) findViewById(R.id.origenText);
        conductor = (TextView) findViewById(R.id.conductorText);
        material = (TextView) findViewById(R.id.materialText);
        peso = (TextView) findViewById(R.id.pesoText);
    }

    void obtenerExtras() //Recupera el id leído por el codigoQR
    {
        Intent intent = getIntent();
        documentoEnvio = intent.getStringExtra("id");
    }

    void recuperarEnvio() //Recupera el envío del ID leído de la base base de datos
    {
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();
        db.document(coleccionEnvios+documentoEnvio)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists())
                        {
                            envioRecuperado = documentSnapshot.toObject(Envio.class);
                            //Recupera todos los elementos del envío en otras colecciones
                            recuperarConductor();
                            recuperarCamion();
                            recuperarContenedor();
                            recuperarProveedor();
                        }
                        else
                        {
                            DespliegaToast("Documento envío no existe.");
                            finish();
                        }
                    }
                });
    }

    void recuperarConductor() //Recupera el conductor
    {
        db.document(coleccionConductores+envioRecuperado.getIdConductor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()) //Si existe el conductor, almacena el nombre
                        {
                            nombreConductor = documentSnapshot.getString("nombre");
                            nombreConductor = nombreConductor + " " + documentSnapshot.getString("apellidos");
                        }
                        else
                        {
                            DespliegaToast("Documento conductor no existe.");
                        }
                    }
                });
    }

    void recuperarCamion() //Recupera el camion
    {
        db.document(coleccionCamiones+envioRecuperado.getPlacasCamion())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()) //Si existe el camión almacena las placas y los detalles
                        {
                            datosCamion = documentSnapshot.getString("marca");
                            datosCamion = datosCamion +" "+ documentSnapshot.getString("modelo");
                            datosCamion = datosCamion + " - " + documentSnapshot.getString("color");
                        }
                        else
                        {
                            DespliegaToast("Documento camión no existe.");
                        }
                    }
                });
    }

    void recuperarContenedor() //Recupera contenedor
    {
        db.document(coleccionContenedores+envioRecuperado.getPlacasContenedor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()) //Si existe el contenedor almacena las placas y los detalles
                        {
                            datosContenedor = documentSnapshot.getString("tipo");
                        }
                        else
                        {
                            DespliegaToast("Documento contenedor no existe.");
                        }
                    }
                });
    }

    void recuperarProveedor() //Recupera el proveedor
    {
        db.document(coleccionProveedores+envioRecuperado.getIdProveedor())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()) //Si existe el proveedor almacena los datos y recupera la dirección
                        {
                            nombreProveedor = documentSnapshot.getString("nombre");
                            recuperarDireccion(coleccionProveedores+envioRecuperado.getIdProveedor());
                        }
                        else
                        {
                            DespliegaToast("Documento proveedor no existe.");
                        }
                    }
                });
    }

    void recuperarDireccion(String url) //Recupera la dirección
    {
        db.document(url+"/direcciones/"+envioRecuperado.getIdDireccion())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()) //Si existe la dirección la almacena
                        {
                            direccionProveedor = "\tColonia: "+documentSnapshot.getString("colonia");
                            direccionProveedor = direccionProveedor +"\n\tCalle:"+ documentSnapshot.getString("calle");
                            direccionProveedor = direccionProveedor +" \n\tNo. "+documentSnapshot.getString("numero");
                            direccionProveedor = direccionProveedor + "\n\tC.P: " + documentSnapshot.getString("codigoPostal");
                            despliegaInformacion();
                        }
                        else
                        {
                            DespliegaToast("Documento dirección no existe.");
                        }
                    }
                });
    }


    private void DespliegaToast(String msg) //Función para desplegar un Toast
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    private void despliegaInformacion() //Función para desplegar la información recuperada
    {
        placasVehiculo.setText("Camión: "+envioRecuperado.getPlacasCamion());
        informacionVehiculo.setText(datosCamion);

        placasContenedor.setText("Contenedor: "+envioRecuperado.getPlacasContenedor());
        informacionContenedor.setText(datosContenedor);

        origen.setText(nombreProveedor+"\n"+direccionProveedor);

        conductor.setText("Conductor: "+nombreConductor);

        material.setText("Material: " + envioRecuperado.getMaterial());
        peso.setText("Peso: " + envioRecuperado.getPeso());

        barradeProgreso.hide();
    }

    public void aceptarBtn(View v) //Función para aceptar el envío
    {
        //get documento envio seet aceptado = 1
        Map<String,Object> datos = new HashMap<>();
        datos.put("aceptado", 1);

        db.collection(coleccionEnvios).document(documentoEnvio).set(datos, SetOptions.merge());
        DespliegaToast("Envío aceptado, el vehículo puede pasar.");

        finish();
    }

    public void negarBtn(View v) //Función para denegar el envío
    {
        Map<String,Object> datos = new HashMap<>();
        datos.put("aceptado", 0);

        db.collection(coleccionEnvios).document(documentoEnvio).set(datos, SetOptions.merge());
        DespliegaToast("Envío denegado correctamente.");

        finish();
    }
}
