package com.samanthabarco.volleyavance;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class aniadirVigilante extends AppCompatActivity {

    Vigilante administrador;
    LinearLayout layout;

    private EditText nombreET;
    private EditText apellidosET;
    private EditText correoET;
    private EditText contraseniaET;
    private RadioGroup radioButtons;

    private String nombreS;
    private String apellidosS;
    private String correoS;
    private String contraseniaS;
    private String permisoS;

    ProgressDialog barradeProgreso;

    private static final String TAG = "Aniadir";
    private String URL_VIGILANTE_INFO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aniadir_vigilante);

        cambiarLayout();
        obtenerElementos();
    }

    void cambiarLayout() //Función para cambiar el layout
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        barradeProgreso = new ProgressDialog(this);
    }

    void obtenerElementos() //Función para obtener los elementos del layout
    {
        nombreET = (EditText) findViewById(R.id.editTextNombre);
        apellidosET = (EditText) findViewById(R.id.editTextApellidos);
        correoET = (EditText) findViewById(R.id.editTextCorreo);
        contraseniaET = (EditText) findViewById(R.id.editTextContrasenia);
        radioButtons = (RadioGroup) findViewById(R.id.radioGroup);
    }

    void vaciarElementos() //Función para vaciar los elementos una vez que se añade el vigilante
    {
        correoET.setText("");
        nombreET.setText("");
        apellidosET.setText("");
        contraseniaET.setText("");
        radioButtons.clearCheck();
        permisoS = null;
    }

    void obtenerStrings() //Obtener strings de los elementos
    {
        nombreS = nombreET.getText().toString();
        apellidosS = apellidosET.getText().toString();
        correoS = correoET.getText().toString();
        contraseniaS = contraseniaET.getText().toString();
    }

    int verificarStrings() //Verifica que los strings sean válidos
    {
        int error = 0;
        if(nombreS.equals("")) {
            nombreET.setError("Debes añadir un nombre.");
            error++;
        }
        if(apellidosS.equals("")) {
            apellidosET.setError("Debes añadir apellidos.");
            error++;
        }
        if(correoS.equals("")) {
            correoET.setError("Debes añadir un correo");
            error++;
        }
        if (correoS.contains(" ") || !correoS.contains("@") || !correoS.contains("."))
        {
            correoET.setError("Correo inválido.");
            error++;
        }
        if(contraseniaS.equals("")) {
            contraseniaET.setError("Debes añadir una contraseña.");
            error++;
        }
        if(permisoS == null) {
            DespliegaToast("Selecciona un cargo.");
            error++;
        }
        if(error>0) return 1;
        return 0;
    }

    public void cargoAdministrador(View v)
    {
        permisoS = "1";
    }

    public void cargoVigilante(View v)
    {
        permisoS = "0";
    }

    void eliminarEspacios() //Cambia espacios por %20 en el nombre antes de enviar la información al servicio
    {
        nombreS = nombreS.replace(" ","%20");
        apellidosS = apellidosS.replace(" ","%20");
    }

    public void setURL() //Asignar correo para acceder al servicio
    {
        eliminarEspacios();
        //"http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/aniadirVigilante.php/?nombre=Nico&apellidos=Barco%20Mejia&correo=nbm2&contrasenia=123&permiso=0";
        URL_VIGILANTE_INFO = "http://ubiquitous.csf.itesm.mx/~pddm-1196844/Parcial3/ProyectoFinal/API/aniadirVigilante.php/?" +
                "nombre="+nombreS+
                "&apellidos="+apellidosS+
                "&correo="+correoS+
                "&contrasenia="+contraseniaS+
                "&permiso="+permisoS;
    }

    public void aniadirVigilante(View v) //Función para añadir el vigilante a la base de datos
    {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);

        obtenerStrings();
        if(verificarStrings()==1) return;
        setURL();

        imm.hideSoftInputFromWindow(contraseniaET.getWindowToken(), 0);

        volleyAniadirVigilante(URL_VIGILANTE_INFO);
    }

    public void volleyAniadirVigilante(String url) //Request para añadir el vigilante a la base de datos
    {
        String  REQUEST_TAG = "com.samanthabarco.volleyavance.aniadirVigilante";
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();

        JsonArrayRequest peticion = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override public void onResponse(JSONArray response) {
                barradeProgreso.hide();
                try {
                    JSONObject autenticacion = (JSONObject) response.get(0);
                    String codigo_autenticacion = autenticacion.getString("Codigo");
                    String mensaje = autenticacion.getString("Mensaje");
                    DespliegaToast(mensaje+".");
                    if(codigo_autenticacion.equals("1"))
                        vaciarElementos();

                } catch (JSONException e) {
                    Toast.makeText(aniadirVigilante.this, "Problema en: " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override public void onErrorResponse(VolleyError error) {
                barradeProgreso.hide();
                Toast.makeText(aniadirVigilante.this, "Error en: " + error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        Singleton.getInstance(getApplicationContext()).addToRequestQueue(peticion,REQUEST_TAG);
        return;
    }

    private void DespliegaToast(String msg) //Función para desplegar un Toast
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }
}
