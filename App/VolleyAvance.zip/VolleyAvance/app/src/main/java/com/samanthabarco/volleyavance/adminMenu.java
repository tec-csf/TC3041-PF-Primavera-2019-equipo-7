package com.samanthabarco.volleyavance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;

public class adminMenu extends AppCompatActivity {

    Vigilante administrador;
    TextView bienvenida;
    LinearLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        //Obtener datos del vigilante
        obtenerVigilante();

        cambiarLayout();
    }

    void obtenerVigilante()
    {
        administrador = new Vigilante();

        //Crear sharedPreferences
        SharedPreferences sp = getSharedPreferences("crm", Context.MODE_PRIVATE);

        Gson gson = new Gson();
        String json = sp.getString("vigilante","");
        administrador = gson.fromJson(json, Vigilante.class);

        return;
    }

    void cambiarBienvenida()
    {
        if(administrador != null)
            bienvenida.setText(administrador.getNombre()+ " " + administrador.getApellidos());
    }

    void cambiarLayout()
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);
        bienvenida = (TextView) findViewById(R.id.nombre);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);

        //Cambiar nombre
        cambiarBienvenida();
    }

    public void aniadirVigilante(View v)
    {
        Intent actividad = new Intent(adminMenu.this, aniadirVigilante.class);
        startActivity(actividad);
    }

    public void eliminarVigilante(View v)
    {
        Intent actividad = new Intent(adminMenu.this, eliminarVigilante.class);
        startActivity(actividad);
    }

    public void administrarVigilante(View v)
    {
        Intent actividad = new Intent(adminMenu.this, administrarVigilante.class);
        startActivity(actividad);
    }

    public void verEntradas(View v)
    {
        Intent actividad = new Intent(adminMenu.this, leerQR.class);
        startActivity(actividad);
    }

    public void salir(View v)
    {
        finish();
    }
}
