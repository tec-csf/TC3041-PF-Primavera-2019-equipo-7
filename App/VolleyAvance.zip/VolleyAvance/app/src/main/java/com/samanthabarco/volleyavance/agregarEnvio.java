package com.samanthabarco.volleyavance;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class agregarEnvio extends AppCompatActivity{

    EditText placasCamionET;
    EditText placasContenedorET;
    EditText proveedorET;
    EditText INEConductorET;
    EditText materialET;
    EditText pesoET;

    String placasCamionS;
    String placasContenedorS;
    String proveedorS;
    String INEConductorS;
    String materialS;
    String pesoS;

    ProgressDialog barradeProgreso;
    Map<String,Object> camion = new HashMap<>();
    Map<String,Object> conductor = new HashMap<>();
    Map<String,Object> contenedor = new HashMap<>();
    Map<String,Object> proveedor = new HashMap<>();
    Map<String,Object> direccion = new HashMap<>();
    Map<String,Object> envio = new HashMap<>();

    String idProveedor;
    String idDireccion;
    String direcciones;

    LinearLayout layout;

    FirebaseFirestore db;

    private static final String TAG = "Recuperar";

    private String coleccionEnvios = "envios/";
    private String coleccionContenedores = "contenedores/";
    private String coleccionConductores = "conductores/";
    private String coleccionCamiones = "camiones/";
    private String coleccionProveedores = "proveedores/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_envio);

        db = FirebaseFirestore.getInstance();

        barradeProgreso = new ProgressDialog(this);

        obtenerElementos();
        cambiarLayout();
    }

    void cambiarLayout()
    {
        //Elementos a cambiar
        layout = (LinearLayout)findViewById(R.id.layout);

        //Eliminar title bar
        getSupportActionBar().hide();

        //Cambiar color de fondo
        layout.setBackgroundColor(Color.WHITE);
    }


    void obtenerElementos()
    {
        placasCamionET = (EditText) findViewById(R.id.placasET);
        placasContenedorET = (EditText) findViewById(R.id.contenedorET);
        proveedorET = (EditText) findViewById(R.id.proveedorET);
        INEConductorET = (EditText) findViewById(R.id.INEConductorET);
        materialET = (EditText) findViewById(R.id.materialET);
        pesoET = (EditText) findViewById(R.id.pesoET);
    }

    void vaciarElementos()
    {
        placasCamionET.setText("");
        placasContenedorET.setText("");
        proveedorET.setText("");
        INEConductorET.setText("");
        materialET.setText("");
        pesoET.setText("");
    }

    void obtenerStrings()
    {
        placasCamionS = placasCamionET.getText().toString();
        placasContenedorS = placasContenedorET.getText().toString();
        proveedorS = proveedorET.getText().toString();
        INEConductorS = INEConductorET.getText().toString();
        materialS = materialET.getText().toString();
        pesoS = pesoET.getText().toString();
    }

    int verificarStrings()
    {
        int error = 0;
        if(placasCamionS.equals("")) {
            placasCamionET.setError("Debes añadir la placa del camión.");
            error++;
        }
        if(placasContenedorS.equals("")) {
            placasContenedorET.setError("Debes añadir la placa del contenedor.");
            error++;
        }
        if(proveedorS.equals("")) {
            proveedorET.setError("Debes añadir el nombre del proveedor, en caso de ser independdiente favor de indicarlo.");
            error++;
        }
        if (INEConductorS .equals(""))
        {
            INEConductorET.setError("Debes añadir el número de INE del conductor.");
            error++;
        }
        if(materialS.equals("")) {
            materialET.setError("Debes indicar el material.");
            error++;
        }
        if(pesoS.equals("")) {
            pesoET.setError("Debes indicar el peso.");
            error++;
        }
        if(error>0) return 1;
        return 0;
    }

    public void siguiente(View v)
    {
        obtenerStrings();
        if(verificarStrings()==1)
            return;
        recuperarProveedor();
        //crearEnvio();
    }

    private void DespliegaToast(String msg)
    {
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
    }

    private void recuperarCamion()
    {
        db.document(coleccionCamiones+placasCamionS)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(!documentSnapshot.exists())
                        {
                            crearCamion();
                        }
                        else
                        {
                            recuperarContenedor();
                        }
                    }
                });
    }

    private void recuperarContenedor()
    {
        db.document(coleccionContenedores+placasContenedorS)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(!documentSnapshot.exists())
                        {
                            crearContenedor();
                        }
                        else
                        {
                            recuperarConductor();
                        }
                    }
                });
    }

    void recuperarConductor()
    {
        db.document(coleccionConductores+INEConductorS)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(!documentSnapshot.exists())
                        {
                            crearConductor();
                        }
                        else
                        {
                            crearEnvio();
                        }
                    }
                });
    }

    void recuperarProveedor()
    {
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();
        db.document(coleccionProveedores+proveedorS)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(!documentSnapshot.exists())
                        {
                            agregarProveedor();
                        }
                        else
                        {
                            recuperarDirecciones(proveedorS);
                            idProveedor = proveedorS;
                            recuperarCamion();
                        }
                    }
                });
    }

    void seleccionarDireccion()
    {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(agregarEnvio.this);
        builder.setTitle("Selecciona una dirección del proveedor");
        builder.setMessage(direcciones);

        //Layout
        LinearLayout layout = new LinearLayout(builder.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30,30,30,30);

        //Añadir EditText
        // Tipo
        final EditText direccionET = new EditText(this);
        direccionET.setInputType(InputType.TYPE_CLASS_NUMBER );
        direccionET.setHint("No. de la dirección");
        //builder.setView(colorET);
        layout.addView(direccionET);

        builder.setView(layout);


        // add a button
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                idDireccion = direccionET.getText().toString();
            }
        });
        // Show the alert dialog
        builder.show();
    }

    void recuperarDirecciones(String proveedor)
    {
        direcciones = "";
        db.collection(coleccionProveedores+proveedor+"/direcciones")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                direcciones = direcciones +document.getId()+":"
                                        +"\n\tCalle: "+document.getString("calle")
                                        +"\n\tNo. "+document.getString("numero")
                                        +"\n\tColonia: "+document.getString("colonia")
                                        +"\n\tC.P. "+document.getString("codigoPostal")+"\n";

                            }
                            seleccionarDireccion();
                        }
                    }
                });

    }

    void crearConductor()
    {

        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(agregarEnvio.this);
        builder.setTitle("Nuevo conductor");
        builder.setMessage("El conductor no se encuentra en la base de datos, favor de completar la información para continuar.");

        //Layout
        LinearLayout layout = new LinearLayout(builder.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30,30,30,30);

        //Añadir EditText
        // Nombre
        final EditText nombreET = new EditText(this);
        nombreET.setInputType(InputType.TYPE_CLASS_TEXT );
        nombreET.setHint("Nombre");
        //builder.setView(colorET);
        layout.addView(nombreET);

        // Color
        final EditText apellidosET = new EditText(this);
        apellidosET.setInputType(InputType.TYPE_CLASS_TEXT);
        apellidosET.setHint("Apellidos");
        //builder.setView(marcaET);
        layout.addView(apellidosET);


        builder.setView(layout);


        // add a button
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                conductor.put("nombre", nombreET.getText().toString());
                conductor.put("apellidos",apellidosET.getText().toString());
                agregarDocumento(coleccionConductores+INEConductorS,conductor);
                crearEnvio();
            }
        });
        // Show the alert dialog
        builder.show();

    }

    void crearCamion()
    {

        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(agregarEnvio.this);
        builder.setTitle("Nuevo camión");
        builder.setMessage("El camión no se encuentra en la base de datos, favor de completar la información para continuar.");

        //Layout
        LinearLayout layout = new LinearLayout(builder.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30,30,30,30);

        //Añadir EditText
        // Color
        final EditText colorET = new EditText(this);
        colorET.setInputType(InputType.TYPE_CLASS_TEXT);
        colorET.setHint("Color del camión");
        //builder.setView(colorET);
        layout.addView(colorET);

        // Color
        final EditText marcaET = new EditText(this);
        marcaET.setInputType(InputType.TYPE_CLASS_TEXT);
        marcaET.setHint("Marca del camión");
        //builder.setView(marcaET);
        layout.addView(marcaET);

        // Color
        final EditText modeloET = new EditText(this);
        modeloET.setInputType(InputType.TYPE_CLASS_TEXT);
        modeloET.setHint("Modelo del camión");
        //builder.setView(modeloET);
        layout.addView(modeloET);

        builder.setView(layout);


        // add a button
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                camion.put("color",colorET.getText().toString());
                camion.put("marca",marcaET.getText().toString());
                camion.put("modelo",modeloET.getText().toString());
                agregarDocumento(coleccionCamiones+placasCamionS,camion);
                recuperarContenedor();
            }
        });
        // Show the alert dialog
        builder.show();

    }

    void crearContenedor()
    {

        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(agregarEnvio.this);
        builder.setTitle("Nuevo contenedor");
        builder.setMessage("El contenedor no se encuentra en la base de datos, favor de completar la información para continuar.");

        //Layout
        LinearLayout layout = new LinearLayout(builder.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30,30,30,30);

        //Añadir EditText
        // Tipo
        final EditText tipoET = new EditText(this);
        tipoET.setInputType(InputType.TYPE_CLASS_TEXT );
        tipoET.setHint("Tipo de contenedor");
        //builder.setView(colorET);
        layout.addView(tipoET);

        builder.setView(layout);


        // add a button
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                contenedor.put("tipo",tipoET.getText().toString());
                agregarDocumento(coleccionContenedores+placasContenedorS,contenedor);
                recuperarConductor();
            }
        });
        // Show the alert dialog
        builder.show();

    }

    void crearDireccion()
    {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(agregarEnvio.this);
        builder.setTitle("Nuevo proveedor");
        builder.setMessage("El proveedor no se encuentra en la base de datos, favor de ingresar una dirección para continuar.");

        //Layout
        LinearLayout layout = new LinearLayout(builder.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30,30,30,30);

        //Añadir EditText
        // Calle
        final EditText calleET = new EditText(this);
        calleET.setInputType(InputType.TYPE_CLASS_TEXT);
        calleET.setHint("Calle");
        //builder.setView(colorET);
        layout.addView(calleET);

        // Colonia
        final EditText numeroET = new EditText(this);
        numeroET.setInputType(InputType.TYPE_CLASS_NUMBER);
        numeroET.setHint("Número");
        //builder.setView(modeloET);
        layout.addView(numeroET);

        // Codigo Postal
        final EditText CPET = new EditText(this);
        CPET.setInputType(InputType.TYPE_CLASS_NUMBER);
        CPET.setHint("Código postal");
        //builder.setView(marcaET);
        layout.addView(CPET);

        // Colonia
        final EditText coloniaET = new EditText(this);
        coloniaET.setInputType(InputType.TYPE_CLASS_TEXT);
        coloniaET.setHint("Colonia");
        //builder.setView(modeloET);
        layout.addView(coloniaET);

        builder.setView(layout);


        // add a button
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                direccion.put("calle",calleET.getText().toString());
                direccion.put("codigoPostal",CPET.getText().toString());
                direccion.put("colonia",coloniaET.getText().toString());
                direccion.put("numero",numeroET.getText().toString());
                agregarDocumento(coleccionProveedores+idProveedor+"/direcciones/1",direccion);
                recuperarCamion();
            }
        });
        // Show the alert dialog
        builder.show();

    }

    void crearEnvio()
    {
        barradeProgreso.setMessage("Cargando...");
        barradeProgreso.show();
        envio.put("idConductor", INEConductorS);
        envio.put("idDireccion",idDireccion);
        envio.put("idProveedor",idProveedor);
        envio.put("material",materialS);
        envio.put("peso",pesoS);
        envio.put("placasCamion",placasCamionS);
        envio.put("placasContenedor",placasContenedorS);
        envio.put("aceptado", 1);

        db.collection("envios")
                .add(envio)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        vaciarElementos();
                        DespliegaToast("Envío aceptado, el vehículo puede pasar");
                        barradeProgreso.hide();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        DespliegaToast("Error, por favor ingrese los datos nuevamente");
                        barradeProgreso.hide();
                    }
                });

    }

    void agregarDocumento(String directorio, Map<String,Object> documento)
    {
        DocumentReference camionRef = db.getInstance().document(directorio);
        camionRef.set(documento)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        //DespliegaToast("Documento añadido correctamente.");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //DespliegaToast("Hubo un error, por favor intenta de nuevo.");
                    }
                });
    }

    void agregarProveedor()
    {
        proveedor.put("nombre", proveedorS);
        db.collection("proveedores")
                .add(proveedor)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        idProveedor = documentReference.getId();
                        idDireccion = "1";
                        //DespliegaToast("Proveedor agregado con ID: " + documentReference.getId());
                        crearDireccion();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //DespliegaToast("Error al añadir proveedor");
                    }
                });
    }

    public void volver(View v)
    {
        finish();

    }

}
