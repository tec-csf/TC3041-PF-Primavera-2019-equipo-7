package com.samanthabarco.volleyavance;

public class Envio {
    private String idConductor;
    private String idDireccion;
    private String idProveedor;
    private String material;
    private String peso;
    private String placasCamion;
    private String placasContenedor;

    public  Envio(){}

    public String getIdConductor(){return idConductor;}

    public String getIdDireccion(){return idDireccion;}

    public String getIdProveedor(){return idProveedor;}

    public String getMaterial(){return material;}

    public String getPeso(){return peso;}

    public String getPlacasCamion(){return placasCamion;}

    public String getPlacasContenedor(){return placasContenedor;}





    public void setIdConductor(String id){this.idConductor = id;}

    public void setIdDireccion(String id){this.idDireccion = id;}

    public void setIdProveedor(String id){this.idProveedor = id;}

    public void setMaterial(String material){this.material = material;}

    public void setPeso(String peso){this.peso = peso;}

    public void setPlacasCamion(String placas){this.placasCamion = placas;}

    public void setPlacasContenedor(String placas){this.placasContenedor = placas;}

}
